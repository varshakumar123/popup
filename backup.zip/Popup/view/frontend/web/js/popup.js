require(
    [
        'jquery',
        'Magento_Ui/js/modal/modal'
    ],
    function (
        $,
        modal
    ) {

        var options = {
            type: 'popup',
            responsive: true,
            innerScroll: false,

            buttons: []
        };

        $(".bt-action").click(function () {
            $(".bt-action-file").modal(options).modal('openModal');

        });
        /*
        a[0]
        var len= array_list.length;
        for(var i=0;i<len;i++){
            for(j=0;j<8;j++){
                if(magnasonic[i][j]==value){
                    var array=new Array();
                    for(var k=0;k<10;k++){
                        array[k]=i;
                    }
                }
            }
        }
        */
        $(".btn").on('click', function () {
            var value = $(this).text();
            var value1 = $(this).html();
            console.log("val-text="+value);
            console.log("val-html="+value1);
        });
        console.log("val-text");
        console.log("val-html=");
        $(".btn").on('click', function () {
            var value = $(this).text();
            var magnasonic = new Array();
            var magnasonic0 = new Array("Sound Base", "SB41");
            var magnasonic1 = new Array("Projector", "PP60");
            var magnasonic2 = new Array("Jewelry Cleaner", "Tank-Capacity-7.4-OZ", "220 ML", "UC21");
            var magnasonic3 = new Array("Jewelry Cleaner", "Tank-Capacity-20-OZ", "600 ML", "1Preset", "CD2800");
            var magnasonic4 = new Array("Jewelry Cleaner", "Tank-Capacity-20-OZ", "600 ML", "5Preset", "MGUC500");
            var magnasonic5 = new Array("Flim Scanner", "Photos", "126 slide", "Screen-size-2.36", "FS52");
            var magnasonic6 = new Array("Flim Scanner", "Photos", "126 slide", "Screen-size-5", "FS71");
            var magnasonic7 = new Array("Flim Scanner", "Photos", "super8 flim-110 slide", "Screen-size-2.36", "Internal Memory-64MB", "FS52");
            var magnasonic8 = new Array("Flim Scanner", "Photos", "super8 flim-110 slide", "Screen-size-2.36", "Internal Memory-128MB", "FS50");
            var magnasonic9 = new Array("Flim Scanner", "Photos", "super8 flim-110 slide", "Screen-size-5", "FS71");
            var magnasonic10 = new Array("Flim Scanner", "Photos", "33MM flim-135 slide-126 flim&slide", "Screen-size-2.4", "MegaPixel-23MP", "FS51");
            var magnasonic11 = new Array("Flim Scanner", "Photos", "33MM flim-135 slide-126 flim&slide", "Screen-size-2.4", "MegaPixel-22MP", "Internal Memory-64MB", "FS52");
            var magnasonic12 = new Array("Flim Scanner", "Photos", "33MM flim-135 slide-126 flim&slide", "Screen-size-2.4", "MegaPixel-22MP", "Internal Memory-128MB", "FS50");
            var magnasonic13 = new Array("Flim Scanner", "Photos", "33MM flim-135 slide-126 flim&slide", "Screen-size-2.4", "MegaPixel-14MP", "FS60");
            var magnasonic14 = new Array("Flim Scanner", "Photos", "33MM flim-135 slide-126 flim&slide", "Screen-size-5", "FS71");
            var magnasonic15 = new Array("Flim Scanner", "Photos", "4x6 photos-3x5 photos", "FS60");
            var magnasonic16 = new Array("Flim Scanner", "Photos", "8MM flim", "FS52");
            var magnasonic17 = new Array("Flim Scanner", "Videos", "8MM video-super 8 video-8MM flim", "FS52");
            var magnasonic18 = new Array("Flim Scanner", "Videos", "8MM video-super 8 video-8MM flim", "FS81");
            var magnasonic19 = new Array("Clock/Radio", "Simple",   "Simple-NO",  "EAAC 200/201"); // Simple = 2/(3+1)*100
            var magnasonic20 = new Array("Clock/Radio", "Simple",   "Simple-YES", "CR 20");
            var magnasonic21 = new Array("Clock/Radio", "Advanced", "USB-NO",     "USB-PROJ-NO", "EAAC 200/201");


            var magnasonic22 = new Array("Clock/Radio", "Advanced", "NO",         "YES",         "NO",           "CR62");
            var magnasonic23 = new Array("Clock/Radio", "Advanced", "NO",         "YES",         "YES",          "EAAC 601");
            var magnasonic24 = new Array("Clock/Radio", "Advanced", "YES",        "NO",          "NO",           "WHITE",    "EAAC 470W");
            var magnasonic25 = new Array("Clock/Radio", "Advanced", "YES",        "NO",          "NO",           "BLUE",     "EAAC 470");
            var magnasonic26 = new Array("Clock/Radio", "Advanced", "YES",        "NO",          "YES",          "CR 63");
            var magnasonic27 = new Array("Clock/Radio", "Advanced", "YES",        "YES",         "YES",          "CR 65");
            var magnasonic28 = new Array("Clock/Radio", "Advanced", "YES",        "YES",         "NO",           "YES",      "CR 64");
            var magnasonic29 = new Array("Clock/Radio", "Advanced", "YES",        "YES",         "NO",           "NO",       "FM Only",  "CR 20");
            var magnasonic30 = new Array("Clock/Radio", "Advanced", "YES",        "YES",         "NO",           "NO",       "AM/FM",    "WHITE",   "EAAC 475W");
            var magnasonic31 = new Array("Clock/Radio", "Advanced", "YES",        "YES",         "NO",           "NO",       "AM/FM",    "BLUE",    "EAAC 475");
            var array_list = [magnasonic0, magnasonic2, magnasonic3, magnasonic4,
                magnasonic5, magnasonic6, magnasonic7, magnasonic8,
                magnasonic9, magnasonic10, magnasonic11, magnasonic12,
                magnasonic13, magnasonic14, magnasonic15, magnasonic16,
                magnasonic17, magnasonic18, magnasonic19, magnasonic20,
                magnasonic21, magnasonic22, magnasonic23, magnasonic24,
                magnasonic25, magnasonic26, magnasonic27, magnasonic28,
                magnasonic29, magnasonic30, magnasonic31, magnasonic1];


                var len= array_list.length;
                var a=0;
                for(var i=0;i<len;i++){
                    var outer_len = array_list[i].length;
                    debugger;
                    var array=new Array(10);
                    var value_arr=[0,1];
                    for(j=0;j<1;j++){
                        
                        if(array_list[i][j]==value){

                            /* value_arr.forEach(function (item,index) { 
                               
                                value_arr[index++]=3; 
                              // value_arr[index++].push("3");
                               console.log(index,item);
                               
                            });  */
                           /* 
                            value_arr[a]=i;
                            a++;
                            console.log( "value "+value_arr[a]);
                             */
                            
                             for(var k=0;k<outer_len;k++){

                                //array.push(i);
                               
                                //console.log(array[k]);
                               // value_arr=array[k];
                                value_arr.push(i);
                                console.log("value_arr1="+value_arr[3]);
                                console.log("value_arr"+value_arr);
                                break;
                            }  
                            /* for(var q in array_list){
                                array[q]=i;
                                console.log("arr"+array[q]); 
                            } */
                           
                        /* } */
                        
                     }
                    
                }
               
            }
            
            }); 



         /*    var arrayLength = array_list.length; 
            // outer = Magnasonic 1 -32
            // outer_len = Individual magnasonic length
            // arrayLength = 32
            // inner = 0
             for (var outer = 0; outer < arrayLength; outer++) {
                var outer_len = array_list[outer].length;

                for (var inner = 0; inner <outer_len; inner++) {
                    if (array_list[outer][inner] == value) {
                        //debugger;
                        var progress =((inner)/outer_len)*100;
                        console.log("outer_len=" + outer_len);
                        //var pb=progress*2;
                        
                        var progress_bar = progress + "%";
                        console.log("pb=" + progress_bar);
                        //$("#hello").css('width',progress);
                        $(".progress-bar").width(progress_bar);
                        // document.getElementById("disk_d").value =(j/sss)*100 ;
                       // console.log("value=" + ((inner / outer_len) * 100));
                        break;
                    }
                }


            }  */
       /*  }); */
            

            /* for (let i in array_list) {
                var len = array_list[i].length;
               // console.log("length= " + len);
                for (var j = 0; j < len; j++) {
                    var z = array_list[i][j];
                    //console.log(z);
                    if (array_list[i][j] == value) { */
            /*  document.getElementById("progress").value =j/100 ; */
            /* alert(z);
            alert("i=" + i);
            alert("j=" + j);
            alert("len=" + len);
            var paring = new Array( i, j);*/
            /* console.log(paring); */

            /* var arr = new Array();
            for (var x = 0; x <= i; x++) {
                arr[x] = i;
            }
            console.log(arr);
             */


            /* var common_option = paring[i, j];
            console.log(paring[i, j]); */



            /*  } */
            /*  let doubledAmounts = [];
                 
                     doubledAmounts[j]=i;
                
                 console.log(doubledAmounts); */
            // break; 
            /*      }
             }
 
         });
  */
       



        /* to show clock/radio */
        $(".clock-radio").on('click', function () {
            $(".clock-radio-subdiv").removeAttr("style");
            $(".magnasonic").hide();
            /* go-back-to-magnasonic */
            $(".go-back-to-magnasonic").on('click', function () {
                $(".magnasonic").show();
                $(".clock-radio-subdiv").hide();
            });
         
        });

        /* to show simple sub div */
        $(".simplebtn").on('click', function () {
            $(".simple-subdiv").removeAttr("style");
            $(".clock-radio-subdiv").hide();
            /* go-back-to-clock-radio-subdiv */
            $(".go-back-to-clock-radio-subdiv").on('click', function () {
                $(".clock-radio-subdiv").show();
                $(".simple-subdiv").hide();
            });
        });

        /* to show simple category with no projection (product)*/
        $(".nobtn").on('click', function () {
            $(".no-projection").removeAttr("style");
            $(".simple-subdiv").hide();
            /* go-back-to-simple-subdiv */
            $(".go-back-to-simple-subdiv").on('click', function () {
                $(".no-projection").hide();
                $(".simple-subdiv").show();
            });
        });

        /* to show simple category with no projection (product)*/
        $(".yesbtn").on('click', function () {
            $(".yes-projection").removeAttr("style");
            $(".simple-subdiv").hide();
            /* go-back-to-simple-subdiv */
            $(".go-back-to-simple-subdiv-yes").on('click', function () {
                $(".yes-projection").hide();
                $(".simple-subdiv").show();
            });
        });

        /* to show advanced category  */
        $(".advancedbtn").on('click', function () {
            $(".advanced-subdiv").removeAttr("style");
            $(".clock-radio-subdiv").hide();
            /* go-back-to-clock-radio-subdiv-from-advanced*/
            $(".go-back-to-clock-radio-subdiv-from-advanced").on('click', function () {
                $(".advanced-subdiv").hide();
                $(".clock-radio-subdiv").show();
            });
        });

        /* to show advanced category with no usb charging */
        $(".usb-nobtn").on('click', function () {
            $(".no-usb-charging").removeAttr("style");
            $(".advanced-subdiv").hide();
            /* go-back-to-usb-charging-from-y/n*/
            $(".go-back-to-usb-charging-from-y-n").on('click', function () {
                $(".advanced-subdiv").show();
                $(".no-usb-charging").hide();
            });
        });

        /* to show advanced category withno usb cgarging no projection (product)*/
        $(".noprojection-usb-nobtn").on('click', function () {
            $(".no-projection-no-usb").removeAttr("style");
            $(".no-usb-charging").hide();
            /* go-back-to-simple-subdiv */
            $(".go-back-to-usb-charging-to-y-n").on('click', function () {
                $(".no-projection-no-usb").hide();
                $(".no-usb-charging").show();
            });
        });

        /* to show advanced category with no usb charging with projection aux input*/
        $(".projection-usb-yesbtn").on('click', function () {
            $(".projection-aux-no-usb-charging").removeAttr("style");
            $(".no-usb-charging").hide();
            /*go-back-to-usb-charging-no-projection */
            $(".go-back-to-usb-charging-no-projection").on('click', function () {
                $(".projection-aux-no-usb-charging").hide();
                $(".no-usb-charging").show();
            });
        });

        /* to show advanced category with no usb charging with projection with no aux input (product) */
        $(".projection-no_aux-usb-nobtn").on('click', function () {
            $(".yes-projection-no-usb").removeAttr("style");
            $(".projection-aux-no-usb-charging").hide();
            /*go-back-to-usb-charging-aux-input */
            $(".go-back-to-usb-charging-aux-input").on('click', function () {
                $(".yes-projection-no-usb").hide();
                $(".projection-aux-no-usb-charging").show();
            });
        });

        /* to show advanced category with no usb charging with projection with  aux input(product) */
        $(".projection-yes_aux-usb-yesbtn").on('click', function () {
            $(".yes-projection-aux-no-usb").removeAttr("style");
            $(".projection-aux-no-usb-charging").hide();
            /* go-back-to-usb-charging-aux-input-from-no */
            $(".go-back-to-usb-charging-aux-input-from-no").on('click', function () {
                $(".yes-projection-aux-no-usb").hide();
                $(".projection-aux-no-usb-charging").show();
            });
        });

        /* to show advanced category with usb charging */
        $(".usb-yesbtn").on('click', function () {
            $(".yes-usb-charging").removeAttr("style");
            $(".advanced-subdiv").hide();
            /*  go-back-to-usb-charging-from-yes */
            $(".go-back-to-usb-charging-from-yes").on('click', function () {
                $(".yes-usb-charging").hide();
                $(".advanced-subdiv").show();
            });
        });

        /* to show advanced category with usb charging no projection*/
        $(".noprojection-usb-nobtn1").on('click', function () {
            $(".yes-usb-charging-ab").removeAttr("style");
            $(".yes-usb-charging").hide();
            /*  go-back-to-usb-charging-yes-projection-from-autobrightness */
            $(".go-back-to-usb-charging-yes-projection-from-autobrightness").on('click', function () {
                $(".yes-usb-charging-ab").hide();
                $(".yes-usb-charging").show();
            });
        });

        /* to show advanced category with usb charging no projection no brightness , color*/
        $(".noab-noprojection-usb-nobtn1").on('click', function () {
            $(".display-color").removeAttr("style");
            $(".yes-usb-charging-ab").hide();
            /* go-back-to-usb-charging-autobrightness-from-displaycolor */
            $(".go-back-to-usb-charging-autobrightness-from-displaycolor").on('click', function () {
                $(".display-color").hide();
                $(".yes-usb-charging-ab").show();
            });
        });

        /* to show advanced category with usb charging no projection no brightness display white(product)*/
        $(".white-btn").on('click', function () {
            $(".no-projection-nobrightness-white-usb").removeAttr("style");
            $(".display-color").hide();
            /*go-back-to-usb-charging-autobrightness-displaycolor-from-product-white */
            $(".go-back-to-usb-charging-autobrightness-displaycolor-from-product-white").on('click', function () {
                $(".no-projection-nobrightness-white-usb").hide();
                $(".display-color").show();
            });
        });

        /* to show advanced category with usb charging no projection no brightness display white(product)*/
        $(".blue-btn").on('click', function () {
            $(".no-projection-nobrightness-blue-usb").removeAttr("style");
            $(".display-color").hide();
            /*go-back-to-usb-charging-autobrightness-displaycolor-from-product-blue */
            $(".go-back-to-usb-charging-autobrightness-displaycolor-from-product-blue").on('click', function () {
                $(".no-projection-nobrightness-blue-usb").hide();
                $(".display-color").show();
            });
        });

        /* to show advanced category with usb charging no projection with brightness (product)*/
        $(".ab-projection-usb-yesbtn1").on('click', function () {
            $(".no-projection-brightness-usb").removeAttr("style");
            $(".yes-usb-charging-ab").hide();
            /*go-back-to-usb-charging-autobrightness-from-product */
            $(".go-back-to-usb-charging-autobrightness-from-product").on('click', function () {
                $(".no-projection-brightness-usb").hide();
                $(".yes-usb-charging-ab").show();
            });
        });

        /* to show advanced category with usb charging no projection*/
        $(".projection-usb-yesbtn1").on('click', function () {
            $(".bluetooth").removeAttr("style");
            $(".yes-usb-charging").hide();
            /*go-back-to-usb-charging-projection-from-bluetooth */
            $(".go-back-to-usb-charging-projection-from-bluetooth").on('click', function () {
                $(".bluetooth").hide();
                $(".yes-usb-charging").show();
            });
        });

        /* to show advanced category with usb charging with projection with bluetooth (product)*/
        $(".bluetooth-yesbtn").on('click', function () {
            $(".projection-bluetooth-usb").removeAttr("style");
            $(".bluetooth").hide();
            /*go-back-to-usb-charging-bluetooth-from-product */
            $(".go-back-to-usb-charging-bluetooth-from-product").on('click', function () {
                $(".projection-bluetooth-usb").hide();
                $(".bluetooth").show();
            });
        });

        /* to show advanced category with usb charging with projection no bluetooth*/
        $(".bluetooth-nobtn").on('click', function () {
            $(".bluetooth-ab").removeAttr("style");
            $(".bluetooth").hide();
            /*go-back-to-usb-charging-bluetooth-from-autobrightness */
            $(".go-back-to-usb-charging-bluetooth-from-autobrightness").on('click', function () {
                $(".bluetooth-ab").hide();
                $(".bluetooth").show();
            });
        });

        /* to show advanced category with usb charging with projection with bluetooth*/
        $(".bluetooth-ab-yesbtn").on('click', function () {
            $(".bluetooth-brightness-usb").removeAttr("style");
            $(".bluetooth-ab").hide();
            /*go-back-to-usb-charging-bluetooth-autobrightness-from-product */
            $(".go-back-to-usb-charging-bluetooth-autobrightness-from-product").on('click', function () {
                $(".bluetooth-brightness-usb").hide();
                $(".bluetooth-ab").show();
            });
        });

        /* to show advanced category with usb charging with projection with bluetooth*/
        $(".bluetooth-ab-nobtn").on('click', function () {
            $(".bluetooth-ab-no").removeAttr("style");
            $(".bluetooth-ab").hide();
            /*go-back-to-usb-charging-autobrightness-from-fm-am */
            $(".go-back-to-usb-charging-autobrightness-from-fm-am").on('click', function () {
                $(".bluetooth-ab-no").hide();
                $(".bluetooth-ab").show();
            });
        });

        /* to show advanced category with usb charging with projection no bluetooth fm only (product)*/
        $(".bluetooth-ab-fm-nobtn").on('click', function () {
            $(".bluetooth-fm-usb").removeAttr("style");
            $(".bluetooth-ab-no").hide();
            /*go-back-to-usb-charging-bluetooth-autobrightness-no-from-fm-product */
            $(".go-back-to-usb-charging-bluetooth-autobrightness-no-from-fm-product").on('click', function () {
                $(".bluetooth-fm-usb").hide();
                $(".bluetooth-ab-no").show();
            });
        });

        /* to show advanced category with usb charging with projection no bluetooth no brightness fm/am only display color*/
        $(".bluetooth-ab-am-yesbtn").on('click', function () {
            $(".display-color-am").removeAttr("style");
            $(".bluetooth-ab-no").hide();
            /*go-back-to-usb-charging-bluetooth-autobrightness-no-am-from-displaycolor */
            $(".go-back-to-usb-charging-bluetooth-autobrightness-no-am-from-displaycolor").on('click', function () {
                $(".display-color-am").hide();
                $(".bluetooth-ab-no").show();
            });
        });

        /* to show advanced category with usb charging with projection no bluetooth am/fm white (product)*/
        $(".white-am-btn").on('click', function () {
            $(".bluetooth-am-white-usb").removeAttr("style");
            $(".display-color-am").hide();
            /*go-back-to-usb-charging-bluetooth-autobrightness-no-from-fm-product-white */
            $(".go-back-to-usb-charging-bluetooth-autobrightness-no-from-fm-product-white").on('click', function () {
                $(".bluetooth-am-white-usb").hide();
                $(".display-color-am").show();
            });
        });

        /* to show advanced category with usb charging with projection no bluetooth am/fm blue (product)*/
        $(".blue-am-btn").on('click', function () {
            $(".bluetooth-am-blue-usb").removeAttr("style");
            $(".display-color-am").hide();
            /*go-back-to-usb-charging-bluetooth-autobrightness-no-from-fm-product-blue */
            $(".go-back-to-usb-charging-bluetooth-autobrightness-no-from-fm-product-blue").on('click', function () {
                $(".bluetooth-am-blue-usb").hide();
                $(".display-color-am").show();
            });
        });

        /* to show sound base (product) */
        $(".sound-base").on('click', function () {
            $(".soundbase-product").removeAttr("style");
            $(".magnasonic").hide();
            /* go-back-to-magnasonic-from-soundbase*/
            $(".go-back-to-magnasonic-from-soundbase").on('click', function () {
                $(".magnasonic").show();
                $(".soundbase-product").hide();
            });
        });
        /* to show projector (product) */
        $(".projector").on('click', function () {
            $(".projector-product").removeAttr("style");
            $(".magnasonic").hide();
            /* go-back-to-magnasonic-from-projector*/
            $(".go-back-to-magnasonic-from-projector").on('click', function () {
                $(".magnasonic").show();
                $(".projector-product").hide();
            });
        });
    }
);














































