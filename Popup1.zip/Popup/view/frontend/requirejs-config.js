var config = {
    map: {
        '*': {
            popupJs:'Tychons_Popup/js/popup',
        }
    }
};







